
export const CONFIG = {
  UNIT: 60,
  X_OFF: 80,
  GROUND_Y: 80,
  BOUNCE: 80,
  RULER_MAX: 30
};
