
export function parabolaY(
  progress:number,
  ground:number,
  bounce:number
){
  return (
    ground -
    4 * bounce *
    progress *
    (1 - progress)
  );
}
