
import { CONFIG }
  from "$lib/config/jumpConfig";

export function drawRulerScale(
  ctx:CanvasRenderingContext2D,
  ground:number
){
  ctx.strokeStyle="#333";

  for(let i=0;i<=CONFIG.RULER_MAX;i++){
    const x =
      CONFIG.X_OFF +
      i * CONFIG.UNIT;

    ctx.beginPath();
    ctx.moveTo(x,ground);
    ctx.lineTo(x,ground+20);
    ctx.stroke();
  }
}
