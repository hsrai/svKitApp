
export function animateJump({
  x1,
  x2,
  duration,
  onUpdate,
  onComplete
}){
  const start = performance.now();

  function frame(now:number){
    const t =
      (now - start) / duration;

    if(t >= 1){
      onUpdate(x2,1);
      onComplete();
      return;
    }

    const x =
      x1 + (x2 - x1) * t;

    onUpdate(x,t);
    requestAnimationFrame(frame);
  }

  requestAnimationFrame(frame);
}
