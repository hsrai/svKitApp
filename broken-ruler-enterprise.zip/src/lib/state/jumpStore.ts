
import { writable } from "svelte/store";

export interface JumpArc {
  x1:number;
  x2:number;
}

export const jumpHistory = writable<JumpArc[]>([]);
export const currentJump = writable(0);
export const isJumping = writable(false);

export const jumpStore = writable({
  rulerMax: 30,
  start: 0,
  pencilLen: 6,
  speed: 5
});
