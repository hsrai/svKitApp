
<script lang="ts">
  import { onMount } from "svelte";

  import { jumpHistory }
    from "$lib/state/jumpStore";

  import { renderStage }
    from "$lib/render/renderStage";

  import { doJumpLogic }
    from "$lib/logic/doJump";

  import { CONFIG }
    from "$lib/config/jumpConfig";

  let canvas:HTMLCanvasElement;
  let ctx:CanvasRenderingContext2D;

  let jokerX:number;
  let jokerY:number;
  let ground:number;

  onMount(()=>{

    ctx = canvas.getContext("2d")!;

    canvas.width =
      canvas.parentElement!.clientWidth;

    canvas.height = 400;

    ground =
      canvas.height - CONFIG.GROUND_Y;

    jokerX = CONFIG.X_OFF;
    jokerY = ground;

    render();
  });

  function setJoker(x:number,y:number){
    jokerX=x;
    jokerY=y;
  }

  function render(){
    renderStage(
      ctx,
      canvas,
      jokerX,
      jokerY,
      $jumpHistory
    );
  }
</script>

<div class="relative h-[400px] bg-white rounded-2xl shadow">

  <canvas
    bind:this={canvas}
    class="absolute inset-0">
  </canvas>

  <button
    on:click={() =>
      doJumpLogic(
        ground,
        setJoker,
        render
      )
    }
    class="absolute top-4 left-4
           bg-green-600 text-white
           px-4 py-2 rounded-xl shadow">

    Jump

  </button>

</div>
