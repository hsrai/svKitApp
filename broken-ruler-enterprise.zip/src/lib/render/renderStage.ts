
import { drawArc }
  from "./drawArc";

import { drawJoker }
  from "./drawJoker";

import { drawRulerScale }
  from "$lib/geometry/rulerScale";

import { drawGroundLine }
  from "$lib/geometry/groundLine";

import { CONFIG }
  from "$lib/config/jumpConfig";

export function renderStage(
  ctx:CanvasRenderingContext2D,
  canvas:HTMLCanvasElement,
  jokerX:number,
  jokerY:number,
  history:{x1:number;x2:number}[]
){
  ctx.clearRect(0,0,canvas.width,canvas.height);

  const ground =
    canvas.height - CONFIG.GROUND_Y;

  drawGroundLine(ctx,canvas.width,ground);
  drawRulerScale(ctx,ground);

  history.forEach(j =>
    drawArc(ctx,j.x1,j.x2,ground,CONFIG.BOUNCE)
  );

  drawJoker(ctx,jokerX,jokerY);
}
