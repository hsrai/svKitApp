
<script lang="ts">
 import Stage
   from "$lib/components/Stage.svelte";
</script>

<div class="max-w-6xl mx-auto p-6">

 <h1 class="text-3xl font-bold text-center mb-6">
   The Mystery of the Broken Ruler
 </h1>

 <Stage />

</div>
