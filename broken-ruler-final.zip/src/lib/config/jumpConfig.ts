
export const CONFIG = {
  UNIT: 60,
  X_OFF: 80,
  GROUND_Y: 90,
  BOUNCE: 70
};
