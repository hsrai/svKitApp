module.exports = {
  content: ['./src/**/*.{svelte,ts}'],
  theme: { extend: {} },
  plugins: [],
};