<details class="bg-white p-4 rounded shadow">
  <summary class="font-bold cursor-pointer">
    Settings
  </summary>

  <div class="mt-3 space-y-2 text-sm">
    <div class="flex justify-between">
      <label>Jump Speed</label>
      <input type="range" min="1" max="10" />
    </div>
  </div>
</details>