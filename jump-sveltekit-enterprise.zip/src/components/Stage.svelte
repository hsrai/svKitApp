<script lang="ts">
  import { onMount } from "svelte";
  import { animateJump } from "$lib/animation/jumpAnimator";
  import { drawArc } from "$lib/canvas/traceRenderer";
  import { CONFIG } from "$lib/config/jumpConfig";

  let canvas: HTMLCanvasElement;
  let ctx: CanvasRenderingContext2D;

  let jumps: {x1:number,x2:number}[] = [];

  onMount(() => {
    ctx = canvas.getContext("2d")!;
    canvas.width = canvas.parentElement!.clientWidth;
    canvas.height = 400;
  });

  function doJump() {

    const x1 = 100;
    const x2 = 160;

    animateJump(
      x1,
      x2,
      600,
      () => {},
      () => {
        jumps.push({x1,x2});
        render();
      }
    );
  }

  function render() {
    ctx.clearRect(0,0,canvas.width,canvas.height);

    jumps.forEach(j =>
      drawArc(
        ctx,
        j.x1,
        j.x2,
        canvas.height - CONFIG.GROUND_Y,
        CONFIG.BOUNCE
      )
    );
  }
</script>

<div class="relative h-[400px] bg-white rounded-xl shadow">
  <canvas bind:this={canvas}
          class="absolute inset-0">
  </canvas>

  <button
    on:click={doJump}
    class="absolute top-4 left-4 bg-green-600 text-white px-4 py-2 rounded">
    Jump
  </button>
</div>