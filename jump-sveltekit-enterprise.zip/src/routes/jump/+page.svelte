<script lang="ts">
  import Stage from "$components/Stage.svelte";
  import SettingsPanel from "$components/SettingsPanel.svelte";
</script>

<div class="max-w-5xl mx-auto p-6 space-y-6">

  <h1 class="text-3xl font-bold text-center">
    Broken Ruler — Enterprise Version
  </h1>

  <Stage />
  <SettingsPanel />

</div>