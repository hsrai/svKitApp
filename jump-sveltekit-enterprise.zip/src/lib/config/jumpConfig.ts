export const CONFIG = {
  UNIT: 60,
  X_OFF: 70,
  GROUND_Y: 100,
  BOUNCE: 100
} as const;