import { parabolaHeight } from "$lib/geometry/parabola";
import { CONFIG } from "$lib/config/jumpConfig";

export function animateJump(
  x1: number,
  x2: number,
  duration: number,
  onFrame: (x: number, y: number) => void,
  onDone: () => void
) {
  const start = performance.now();

  function frame(now: number) {
    let p = (now - start) / duration;
    if (p > 1) p = 1;

    const x = x1 + (x2 - x1) * p;
    const h = parabolaHeight(p, CONFIG.BOUNCE);

    const y =
      CONFIG.GROUND_Y + h;

    onFrame(x, y);

    if (p < 1) {
      requestAnimationFrame(frame);
    } else {
      onDone();
    }
  }

  requestAnimationFrame(frame);
}