export function drawArc(
  ctx: CanvasRenderingContext2D,
  x1: number,
  x2: number,
  groundY: number,
  bounce: number
) {
  const mid = (x1 + x2) / 2;
  const peak = groundY - bounce;

  ctx.beginPath();
  ctx.moveTo(x1, groundY);
  ctx.quadraticCurveTo(
    mid,
    peak,
    x2,
    groundY
  );
  ctx.stroke();
}