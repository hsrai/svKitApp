import { writable } from "svelte/store";

export interface JumpArc {
  x1: number;
  x2: number;
}

export const currentJump = writable(0);
export const jumpHistory = writable<JumpArc[]>([]);
export const isJumping = writable(false);