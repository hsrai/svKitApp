export function parabolaHeight(
  progress: number,
  bounce: number
): number {
  return (
    2 *
    bounce *
    progress *
    (1 - progress)
  );
}