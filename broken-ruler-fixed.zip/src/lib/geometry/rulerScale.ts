
export function drawRulerScale(
  ctx: CanvasRenderingContext2D,
  width: number,
  ground: number,
  unit: number
) {
  ctx.strokeStyle = "#333";
  ctx.fillStyle = "#111";
  ctx.lineWidth = 2;
  ctx.font = "12px sans-serif";
  ctx.textAlign = "center";

  let count = Math.floor(width / unit);

  for (let i = 0; i <= count; i++) {
    const x = i * unit;

    // Tick
    ctx.beginPath();
    ctx.moveTo(x, ground);
    ctx.lineTo(x, ground + 15);
    ctx.stroke();

    // Number
    ctx.fillText(
      String(i),
      x,
      ground + 30
    );
  }
}
